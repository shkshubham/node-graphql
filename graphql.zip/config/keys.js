const mongodb = {
    url: "mongodb://root:sa123@ds135747.mlab.com:35747/wirecamp_graphql"
}

module.exports = {
    mongodb
}